#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include "robot_arms.h"

float origin[3] = {80.0, 20.0, 0.0}; //origin
float goal[3] = {40.0, 30.0, 10.0}; //goal
float mutation_rate = 0.1;
Angles *pop;
int best;

/*
void Draw(void) {

    //draw all arms
	float x, y, prevx = origin[0], prevy = origin[1];
    int i, j;
    for ( j = 0; j < POP; j++){
	    glBegin(GL_LINE_STRIP); //draw lines in sequence
	        glColor3f(0.5f, 0.5f, 0.5f); //define gray
	        prevx = origin[0];
	        prevy = origin[1];

	        glVertex2f(prevx, prevy);

	        for ( i = 0; i < ARMS; i++){
	        	x = prevx + cos(pop[j].val[i])*ARM_SIZE;
				y = prevy + sin(pop[j].val[i])*ARM_SIZE;
				prevx = x;
				prevy = y;

	        	glVertex2f(x, y);
	        }

	    glEnd();
    }

    //draw best arms
    glBegin(GL_LINE_STRIP);
        glColor3f(1.0f, 1.0f, 1.0f);

        //float x, y, prevx = origin[0], prevy = origin[1];
        //int i;
        prevx = origin[0];
        prevy = origin[1];

        glVertex2f(prevx, prevy);
        for (i = 0; i < ARMS; i++){
        	x = prevx + cos(pop[best].val[i])*ARM_SIZE;
			y = prevy + sin(pop[best].val[i])*ARM_SIZE;
			prevx = x;
			prevy = y;

        	glVertex2f(x, y);
        }
}*/

void Keyboard(char key){
    //ENTER
   if (key == '\n' || key == '\0'){
	 	crossover(pop, best, mutation_rate);
	 	best = selection(pop, origin, goal);
	 	show_result(pop, origin, goal);
    }

    //reset
    if(key == 'r'){
    	destroy(pop);
    	printf("\n-----------------------------------------------\n");
    	printf("\nOld population destroyed and a new initialized!\n\n");
    	pop = init_pop();
    	best = selection(pop, origin, goal);
	 	show_result(pop, origin, goal);
	 	mutation_rate = 0.1;
    }

    //increase mutation rate
    if (key == 'p'){
    	mutation_rate *= 10.0;
    }

    //decrease mutation rate
    if (key == 'o'){
    	mutation_rate /= 10.0;
    }
}

//just explain the commands
void instruction(){
	printf("\nr: restart\n");
	printf("ENTER: new generation\n");
	printf("p: increase mutation rate\n");
	printf("o: decrease mutation rate\n");
	printf("e: exit\n\n");
	printf("-------------------------\n\n");
}

int main(int argc, char *argv[]){
    char key = '\0';
    //instruction();

    pop = init_pop();
    best = selection(pop, origin, goal);

    while (key != 'e'){
        //show_result(pop, origin, goal);
        instruction();
        key = getchar();
        Keyboard(key);
    }

	destroy(pop);

	return 0;
}
