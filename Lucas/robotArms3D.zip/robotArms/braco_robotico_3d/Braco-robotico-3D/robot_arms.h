#ifndef ROBOT_ARMS_H
#define ROBOT_ARMS_H

#define POP 10 //number of individuals
#define ARMS 10 //number of arms
#define PI 3.14159265359
#define ARM_SIZE 10.0

typedef struct angles{
	float *val;
	float *z_plan;
}Angles;

Angles *init_pop();

float fitness(float origin[3], float goal[3], float *angles, float *z_plan);

int selection(Angles *pop, float origin[3], float goal[3]);

void crossover(Angles *pop, int best, float mutation_rate);

void show_result(Angles *pop, float origin[3], float goal[3]);

void destroy(Angles *pop);

#endif
