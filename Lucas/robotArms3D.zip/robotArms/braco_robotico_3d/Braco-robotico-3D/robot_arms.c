#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include "robot_arms.h"

//step 1
//declara um array de indivios populados
Angles *init_pop(){
	Angles *pop = (Angles *)malloc(POP * sizeof(Angles));

	if(pop == NULL){
		printf("ERROR! pop is null\n");
		exit(0);
	}

	int i;
	int pi20000 = 2*PI*100; //2PI = 360 graus
	//printf("pi2000: %d\n", pi20000);

	srand(time(NULL));
	//printf("Rand: %d\n", rand());
	//printf("Rand\%2*PI: %f\n", rand()%pi20000*1.0);

    //popula individuo com numers aleatorios
	for (i = 0; i < POP; i++){
		pop[i].val = (float *)malloc(ARMS * sizeof(float));
		pop[i].z_plan = (float *)malloc(ARMS * sizeof(float));

		for (int j = 0; j < ARMS; j++){
			pop[i].val[j] = rand()%pi20000*1.0/100; //criar um numero randomico entre 0 e 2*PI
			pop[i].z_plan[j] = ((rand()%pi20000*1.0/2)/100)-(PI/2); //criar um numero randomico entre 0 e 2*PI
			//printf("pop[%d]: %.4f\n", i, pop[i].val[j]);
		}
	}

	return pop;
}

//step 2
//evalute, in this case the less the better
float fitness(float origin[3], float goal[3], float *angles, float *z_plan){

	float x, y, z, prevx = origin[0], prevy = origin[1], prevz = origin[2];
	int i;

	for (i = 0; i < ARMS; i++){
		x = prevx + cos(angles[i])*ARM_SIZE;
		y = prevy + sin(angles[i])*ARM_SIZE;
		z = prevz + sin(z_plan[i])*ARM_SIZE;
		prevx = x;
		prevy = y;
		prevz = z;
	}

	return sqrt((x - goal[0])*(x - goal[0]) + (y - goal[1])*(y - goal[1]) + (z - goal[2])*(z - goal[2]));
}

//step 3
//return the index of the best
int selection(Angles *pop, float origin[3], float goal[3]){
	int best = 0;
	for (int i = 1; i < POP; ++i){
		if(fitness(origin, goal, pop[i].val, pop[i].z_plan) < fitness(origin, goal, pop[best].val, pop[best].z_plan))
			best = i;
	}
	return best;
}

//step 4, 5, 6
//crossover, mutation and new population
void crossover(Angles *pop, int best, float mutation_rate){
	int i, j;

	for (i = 0; i < POP; i++){

		if (i == best) continue;

		for (j = 0; j < ARMS; j++){
			//crossover
			pop[i].val[j] += pop[best].val[j];
			pop[i].val[j] /= 2;
			pop[i].val[j] += pop[best].z_plan[j];
			pop[i].val[j] /= 2;

			//mutation
			if (rand()%2) pop[i].val[j] *= (1+mutation_rate);
			else pop[i].val[j] *= (1-mutation_rate);
			if (rand()%2) pop[i].z_plan[j] *= (1+mutation_rate);
			else pop[i].z_plan[j] *= (1-mutation_rate);
		}
	}
}

//show results
void show_result(Angles *pop, float origin[3], float goal[3]){

	float x, y, z, prevx = origin[0], prevy = origin[1], prevz = origin[2];
	int i, j;

	for (i = 0; i < POP; ++i){
		//printf("Individual: %d:\n", i);

		prevx = origin[0];
		prevy = origin[1];
		prevz = origin[2];
		for (j = 0; j < ARMS; j++){
            x = prevx + cos(pop[i].val[j])*ARM_SIZE;
            y = prevy + sin(pop[i].val[j])*ARM_SIZE;
            z = prevz + sin(pop[i].z_plan[i])*ARM_SIZE;
            prevx = x;
            prevy = y;
            prevz = z;
            //esse print abaixo mostra todos os pontos x, y
			//printf("a:%.4f\tx:%.4f\ty:%.4f\n", pop[i].val[j], x, y);
		}
		printf("Fitness[%d]: %.2f\n", i, fitness(origin, goal, pop[i].val, pop[i].z_plan));
	}
	printf("Best index: %d\n\n", selection(pop, origin, goal));
}

//free memory
void destroy(Angles *pop){
	int i;

	for (i = 0; i < POP; i++){
		free(pop[i].val);
		free(pop[i].z_plan);
	}
	free(pop);
}
